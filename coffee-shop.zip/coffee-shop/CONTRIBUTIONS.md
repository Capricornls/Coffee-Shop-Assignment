# Member Contribution Report

Group name: ____________________  Course: BSc. Software Engineering and Multimedia

| Member | Student ID | Main responsibilities | Branches / PRs | Approx. contribution |
|---|---|---|---|---|
| | | e.g. Express API: menu endpoints | | % |
| | | e.g. React: customer menu and cart | | % |
| | | e.g. Redis + deployment | | % |
| | | e.g. Staff dashboard + testing | | % |

## Details per member

### Member 1: name
- What I built:
- Key commits / pull requests (links):
- What I learned / challenges:

(repeat for each member)

## Screenshots checklist
- [ ] Customer menu, cart, order confirmation
- [ ] Staff dashboard: orders, menu management, daily summary
- [ ] Redis records (menu:* and order:* keys)
- [ ] /api/health on the live backend
