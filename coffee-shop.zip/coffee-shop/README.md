# Coffee Shop Management System

Group assignment: full-stack web app for a local coffee shop. Customers browse the menu, fill a cart and place orders. Staff log in to manage the menu, move orders through their statuses and see a daily summary.

| Layer | Technology | Hosting |
|---|---|---|
| Frontend | React 19 + Vite + React Router, Fetch API | Vercel or Netlify |
| Backend | Node.js + Express REST API (ES modules) | Render |
| Database | Redis (key-value NoSQL, AOF persistence) | Upstash / Redis Cloud / Render Key Value |
| Collaboration | GitHub (branches + pull requests) | GitHub |

## Project structure

```
coffee-shop/
├── backend/             Express API
│   ├── src/             app.js, server.js, store.js (Redis), auth.js, validate.js, routes/
│   └── tests/           API integration tests
├── frontend/            React app
│   └── src/             pages/, components/, context/, api.js
└── CONTRIBUTIONS.md     Template for the member contribution report
```

## Run it locally

You need Node.js 18+ and a Redis server (local, or a free cloud one).

**1. Redis (local, persistence on)**
```bash
redis-server --appendonly yes
```

**2. Backend**
```bash
cd backend
npm install
cp .env.example .env      # then edit the values
npm start                 # http://localhost:4000/api/health
```

**3. Frontend**
```bash
cd frontend
npm install
cp .env.example .env      # VITE_API_URL=http://localhost:4000
npm run dev               # http://localhost:5173
```

On first start the backend adds the sample menu (espresso, americano, cappuccino, latte, flat white, mocha, macchiato, cortado, matcha, tea, pastries). Existing items are kept. Staff log in at `/staff/login` with the `STAFF_USERNAME` / `STAFF_PASSWORD` from `backend/.env`.

**Tests** (needs Redis running; uses database 15 and wipes it): `cd backend && npm test`

## Environment variables

Backend (`backend/.env`, set in the Render dashboard when deployed)

| Variable | Meaning |
|---|---|
| `PORT` | Port to listen on (Render sets this itself) |
| `REDIS_URL` | Redis connection string, e.g. `rediss://default:password@host:port` |
| `CORS_ORIGIN` | Frontend URL(s), comma separated, e.g. `https://my-coffee.vercel.app` |
| `STAFF_USERNAME`, `STAFF_PASSWORD` | Staff login |
| `JWT_SECRET` | Long random string used to sign login tokens |

Frontend (`frontend/.env`, set in Vercel/Netlify)

| Variable | Meaning |
|---|---|
| `VITE_API_URL` | Public URL of the Render backend, no trailing slash |

Credentials live only in environment variables and are never committed (`.env` is git-ignored).

## How data is stored in Redis

Every record is a key holding a JSON string:

| Key | Value |
|---|---|
| `menu:<uuid>` | one menu item `{ id, name, description, category, price, available, hasSizes }` |
| `menu:ids` | set of all menu ids |
| `order:<uuid>` | one order `{ id, orderNumber, customerName, items[], total, status, createdAt }` |
| `orders:ids` | set of all order ids |
| `orders:counter` | counter used to create order numbers (CS-1001, CS-1002, ...) |

IDs are random UUIDs. Order totals are calculated on the server from the stored menu prices, so customers cannot change prices.

## API endpoints

Base URL: `http://localhost:4000` locally, your Render URL when deployed. Errors always look like `{ "error": "message", "details": [...] }` with a suitable status code (400 validation, 401/403 auth, 404 not found, 409 item unavailable, 500 server).

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | public | Backend and database check |
| POST | `/api/auth/login` | public | Staff login, returns `{ token }` |
| GET | `/api/menu` | public | All menu items |
| GET | `/api/menu/:id` | public | One menu item |
| POST | `/api/menu` | staff | Add a menu item |
| PUT | `/api/menu/:id` | staff | Update name, price, availability, etc. |
| DELETE | `/api/menu/:id` | staff | Delete a menu item |
| POST | `/api/orders` | public | Place an order (returns order number) |
| GET | `/api/orders/:id` | public | One order (confirmation page) |
| GET | `/api/orders` | staff | All orders, optional `?status=Pending` |
| PATCH | `/api/orders/:id/status` | staff | Set status: Pending, Preparing, Ready, Collected |
| GET | `/api/orders/summary/daily` | staff | Orders, items sold, sales and status counts for `?date=YYYY-MM-DD` |

Staff routes need the header `Authorization: Bearer <token>`.

Example order:
```json
POST /api/orders
{ "customerName": "Thabo", "notes": "oat milk", "items": [{ "menuItemId": "<id>", "size": "Large", "quantity": 2 }] }
```

### Sizes

Drinks have `hasSizes: true`. The item's `price` is the **Small** price; **Medium adds M5** and **Large adds M10** (set in `backend/src/sizes.js`). The menu endpoints return a `sizePrices` object for sized items, and each order line stores the chosen `size`. Items without sizes (pastries) ignore `size`. Staff turn sizes on or off per item in Manage menu.

## Deployment

Deploy in this order: database, backend, frontend, then go back and set `CORS_ORIGIN`.

**1. Database (Redis with persistence)**
Create a free database on [Upstash](https://upstash.com) (or Redis Cloud). Persistence is on by default for these services. Copy the `rediss://...` connection URL. It is your `REDIS_URL`.

**2. Backend on Render**
1. Push the repo to GitHub.
2. Render: New, Web Service, choose the repo.
3. Root directory `backend`, build command `npm install`, start command `npm start`.
4. Add the environment variables from the table above.
5. When it is live, open `https://<your-service>.onrender.com/api/health`. It should return `{"status":"ok","database":"connected"}`. (Free Render services sleep when idle, so the first request can take about 50 seconds.)

**3. Frontend on Vercel (or Netlify)**
1. New project, choose the same repo, root directory `frontend`.
2. Framework preset: Vite. Build `npm run build`, output `dist`.
3. Add `VITE_API_URL` = your Render URL.
4. Deploy. `vercel.json` and `public/_redirects` make page refreshes on routes like `/cart` work.

**4. Finish**
Set the backend's `CORS_ORIGIN` to the frontend URL in Render and let it redeploy.

## Demo script (for the presentation)

1. Open the site and show the menu with unavailable items greyed out.
2. Log in as staff, Manage menu, add a new item (e.g. Mocha).
3. Go back to Menu, add items to the cart, change quantities, enter a name and place the order. Show the order number.
4. Staff dashboard, Orders: change the status Pending, Preparing, Ready, Collected. Show the customer confirmation page updating.
5. Show Daily summary, then the keys in the Redis console (screenshots for the report).

## GitHub workflow

- `main` is always working. Each member works on a feature branch (`feature/menu-page`, `feature/orders-api`, ...) and opens a pull request that another member reviews.
- Use clear commit messages. The commit history and pull requests show each member's contribution. Summarise them in `CONTRIBUTIONS.md`.

## Security notes

- Staff routes are protected with a signed JWT (8 hour expiry). Passwords are compared in constant time.
- All input is validated on the server; request bodies are limited to 50 KB.
- Passwords, secrets and the database URL are environment variables only.
