import { useEffect, useState } from 'react';
import { api, formatPrice } from '../api';
import { useAuth } from '../context/AuthContext';

export default function SummaryTab() {
  const { token, logout } = useAuth();
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api(`/api/orders/summary/daily?date=${date}`, { token })
      .then((data) => { setSummary(data); setError(''); })
      .catch((e) => (e.status === 401 ? logout() : setError(e.message)));
  }, [date, token, logout]);

  return (
    <>
      <label className="inline">Date <input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
      {error && <p className="alert error">{error}</p>}
      {summary && (
        <>
          <div className="stats">
            <div className="stat"><span>Orders</span><strong>{summary.orderCount}</strong></div>
            <div className="stat"><span>Items sold</span><strong>{summary.itemsSold}</strong></div>
            <div className="stat"><span>Total sales</span><strong>{formatPrice(summary.totalSales)}</strong></div>
          </div>
          <h3>Orders by status</h3>
          <div className="stats">
            {Object.entries(summary.byStatus).map(([status, n]) => (
              <div className="stat" key={status}><span className={`status ${status}`}>{status}</span><strong>{n}</strong></div>
            ))}
          </div>
          <p className="muted">Dates are based on UTC.</p>
        </>
      )}
    </>
  );
}
