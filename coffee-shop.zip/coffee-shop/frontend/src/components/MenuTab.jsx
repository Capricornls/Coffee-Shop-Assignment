import { useCallback, useEffect, useState } from 'react';
import { api, formatPrice } from '../api';
import { useAuth } from '../context/AuthContext';

const EMPTY_FORM = { name: '', description: '', category: 'Coffee', price: '', available: true, hasSizes: true };

export default function MenuTab() {
  const { token, logout } = useAuth();
  const [menu, setMenu] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState('');

  const handleError = useCallback((e) => {
    if (e.status === 401) logout();
    else setError(e.message);
  }, [logout]);

  const load = useCallback(() => {
    api('/api/menu').then(setMenu).catch(handleError);
  }, [handleError]);

  useEffect(load, [load]);

  function updateField(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function save(event) {
    event.preventDefault();
    setError('');
    const body = { ...form, price: Number(form.price) };
    try {
      if (editingId) await api(`/api/menu/${editingId}`, { method: 'PUT', token, body });
      else await api('/api/menu', { method: 'POST', token, body });
      setForm(EMPTY_FORM);
      setEditingId(null);
      load();
    } catch (e) {
      handleError(e);
    }
  }

  function startEdit(item) {
    setEditingId(item.id);
    setForm({ name: item.name, description: item.description, category: item.category, price: item.price, available: item.available, hasSizes: !!item.hasSizes });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function toggleAvailable(item) {
    try {
      await api(`/api/menu/${item.id}`, { method: 'PUT', token, body: { available: !item.available } });
      load();
    } catch (e) {
      handleError(e);
    }
  }

  async function remove(item) {
    if (!window.confirm(`Delete "${item.name}" from the menu?`)) return;
    try {
      await api(`/api/menu/${item.id}`, { method: 'DELETE', token });
      load();
    } catch (e) {
      handleError(e);
    }
  }

  return (
    <>
      <form className="panel" onSubmit={save}>
        <h2>{editingId ? 'Edit menu item' : 'Add menu item'}</h2>
        <div className="form-grid">
          <label>Name<input value={form.name} onChange={(e) => updateField('name', e.target.value)} required /></label>
          <label>Category
            <input list="categories" value={form.category} onChange={(e) => updateField('category', e.target.value)} required />
            <datalist id="categories"><option>Coffee</option><option>Tea</option><option>Pastry</option><option>Other</option></datalist>
          </label>
          <label>{form.hasSizes ? 'Small price (M)' : 'Price (M)'}<input type="number" step="0.01" min="0.01" value={form.price} onChange={(e) => updateField('price', e.target.value)} required /></label>
          <label>Description<input value={form.description} onChange={(e) => updateField('description', e.target.value)} maxLength={200} /></label>
        </div>
        <label className="check">
          <input type="checkbox" checked={form.available} onChange={(e) => updateField('available', e.target.checked)} /> Available
        </label>
        <label className="check">
          <input type="checkbox" checked={form.hasSizes} onChange={(e) => updateField('hasSizes', e.target.checked)} /> Comes in Small / Medium / Large (Medium +M5, Large +M10)
        </label>
        {error && <p className="alert error">{error}</p>}
        <div className="row">
          <button className="btn">{editingId ? 'Save changes' : 'Add item'}</button>
          {editingId && <button type="button" className="btn secondary" onClick={() => { setEditingId(null); setForm(EMPTY_FORM); }}>Cancel</button>}
        </div>
      </form>

      <table className="table">
        <thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Sizes</th><th>Available</th><th>Actions</th></tr></thead>
        <tbody>
          {menu.map((item) => (
            <tr key={item.id}>
              <td>{item.name}</td>
              <td>{item.category}</td>
              <td>{formatPrice(item.price)}</td>
              <td>{item.hasSizes ? 'S / M / L' : '-'}</td>
              <td><input type="checkbox" checked={item.available} onChange={() => toggleAvailable(item)} aria-label={`${item.name} available`} /></td>
              <td>
                <button className="link" onClick={() => startEdit(item)}>Edit</button>{' '}
                <button className="link danger" onClick={() => remove(item)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
