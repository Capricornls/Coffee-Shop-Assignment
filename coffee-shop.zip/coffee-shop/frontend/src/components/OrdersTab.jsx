import { useCallback, useEffect, useState } from 'react';
import { api, formatPrice } from '../api';
import { useAuth } from '../context/AuthContext';

const STATUSES = ['Pending', 'Preparing', 'Ready', 'Collected'];

export default function OrdersTab() {
  const { token, logout } = useAuth();
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState('All');
  const [error, setError] = useState('');

  const handleError = useCallback((e) => {
    if (e.status === 401) logout();
    else setError(e.message);
  }, [logout]);

  const load = useCallback(() => {
    api('/api/orders', { token }).then((data) => { setOrders(data); setError(''); }).catch(handleError);
  }, [token, handleError]);

  useEffect(() => {
    load();
    const timer = setInterval(load, 15000);
    return () => clearInterval(timer);
  }, [load]);

  async function changeStatus(id, status) {
    try {
      const updated = await api(`/api/orders/${id}/status`, { method: 'PATCH', token, body: { status } });
      setOrders((current) => current.map((o) => (o.id === id ? updated : o)));
    } catch (e) {
      handleError(e);
    }
  }

  const visible = filter === 'All' ? orders : orders.filter((o) => o.status === filter);

  return (
    <>
      <div className="chips">
        {['All', ...STATUSES].map((s) => (
          <button key={s} className={s === filter ? 'chip active small' : 'chip small'} onClick={() => setFilter(s)}>{s}</button>
        ))}
      </div>
      {error && <p className="alert error">{error}</p>}
      {visible.length === 0 && <p className="muted">No orders to show.</p>}
      <div className="grid">
        {visible.map((order) => (
          <article key={order.id} className="card">
            <div className="row between">
              <strong>{order.orderNumber}</strong>
              <span className={`status ${order.status}`}>{order.status}</span>
            </div>
            <p>{order.customerName} <span className="muted">· {new Date(order.createdAt).toLocaleString()}</span></p>
            <ul className="plain">
              {order.items.map((l) => <li key={l.menuItemId + (l.size || '')}>{l.quantity} × {l.name}{l.size && ` (${l.size})`}</li>)}
            </ul>
            {order.notes && <p className="muted">Notes: {order.notes}</p>}
            <div className="card-footer">
              <strong>{formatPrice(order.total)}</strong>
              <select value={order.status} onChange={(e) => changeStatus(order.id, e.target.value)}>
                {STATUSES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
          </article>
        ))}
      </div>
    </>
  );
}
