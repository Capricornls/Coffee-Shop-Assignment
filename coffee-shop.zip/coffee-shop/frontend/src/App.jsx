import { Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { useCart } from './context/CartContext';
import { useAuth } from './context/AuthContext';
import MenuPage from './pages/MenuPage';
import CartPage from './pages/CartPage';
import ConfirmationPage from './pages/ConfirmationPage';
import StaffLoginPage from './pages/StaffLoginPage';
import StaffDashboard from './pages/StaffDashboard';

export default function App() {
  const { count } = useCart();
  const { token } = useAuth();

  return (
    <>
      <header className="topbar">
        <NavLink to="/" className="brand">Bean There Coffee</NavLink>
        <nav>
          <NavLink to="/" end>Menu</NavLink>
          <NavLink to="/cart">Cart{count > 0 && <span className="badge">{count}</span>}</NavLink>
          <NavLink to={token ? '/staff' : '/staff/login'}>Staff</NavLink>
        </nav>
      </header>
      <main className="container">
        <Routes>
          <Route path="/" element={<MenuPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/order/:id" element={<ConfirmationPage />} />
          <Route path="/staff/login" element={<StaffLoginPage />} />
          <Route path="/staff" element={token ? <StaffDashboard /> : <Navigate to="/staff/login" replace />} />
          <Route path="*" element={<p>Page not found.</p>} />
        </Routes>
      </main>
    </>
  );
}
