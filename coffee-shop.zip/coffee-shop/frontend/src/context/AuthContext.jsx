import { createContext, useContext, useState } from 'react';
import { api } from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => {
    try {
      return sessionStorage.getItem('staffToken');
    } catch {
      return null;
    }
  });

  async function login(username, password) {
    const data = await api('/api/auth/login', { method: 'POST', body: { username, password } });
    setToken(data.token);
    try {
      sessionStorage.setItem('staffToken', data.token);
    } catch {
      /* ignore */
    }
  }

  function logout() {
    setToken(null);
    try {
      sessionStorage.removeItem('staffToken');
    } catch {
      /* ignore */
    }
  }

  return <AuthContext.Provider value={{ token, login, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
