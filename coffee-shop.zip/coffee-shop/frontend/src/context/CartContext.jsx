import { createContext, useContext, useEffect, useState } from 'react';

const CartContext = createContext(null);

function loadCart() {
  try {
    const saved = JSON.parse(localStorage.getItem('cart')) || [];
    return saved.filter((i) => i.key); // ignore carts saved by older versions
  } catch {
    return [];
  }
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(loadCart);

  useEffect(() => {
    try {
      localStorage.setItem('cart', JSON.stringify(items));
    } catch {
      /* storage may be blocked; the cart still works in memory */
    }
  }, [items]);

  // size is 'Small' / 'Medium' / 'Large' for drinks, or null for items without sizes.
  // The same drink in two sizes is two separate cart lines.
  function addItem(menuItem, size) {
    const key = `${menuItem.id}-${size || 'none'}`;
    const price = size && menuItem.sizePrices ? menuItem.sizePrices[size] : menuItem.price;
    setItems((current) => {
      const existing = current.find((i) => i.key === key);
      if (existing) return current.map((i) => (i.key === key ? { ...i, quantity: Math.min(i.quantity + 1, 20) } : i));
      return [...current, { key, id: menuItem.id, name: menuItem.name, size, price, quantity: 1 }];
    });
  }

  function setQuantity(key, quantity) {
    if (quantity < 1) return removeItem(key);
    setItems((current) => current.map((i) => (i.key === key ? { ...i, quantity: Math.min(quantity, 20) } : i)));
  }

  function removeItem(key) {
    setItems((current) => current.filter((i) => i.key !== key));
  }

  const clear = () => setItems([]);
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const count = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider value={{ items, addItem, setQuantity, removeItem, clear, total, count }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
