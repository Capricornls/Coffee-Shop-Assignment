// All communication with the Express backend goes through the Fetch API here.
const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:4000').replace(/\/$/, '');

export async function api(path, { method = 'GET', body, token } = {}) {
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  let response;
  try {
    response = await fetch(API_URL + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('Cannot reach the server. Please try again in a moment.');
  }

  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const details = data.details ? `: ${data.details.join(', ')}` : '';
    const error = new Error((data.error || 'Request failed') + details);
    error.status = response.status;
    throw error;
  }
  return data;
}

export const formatPrice = (n) => `M${Number(n).toFixed(2)}`;
