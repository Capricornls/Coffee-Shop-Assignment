import { useEffect, useState } from 'react';
import { api, formatPrice } from '../api';
import { useCart } from '../context/CartContext';

export default function MenuPage() {
  const [menu, setMenu] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [category, setCategory] = useState('All');
  const { addItem, items } = useCart();
  // Chosen size per menu item id (defaults to Small)
  const [sizes, setSizes] = useState({});

  useEffect(() => {
    api('/api/menu')
      .then(setMenu)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const categories = ['All', ...new Set(menu.map((m) => m.category))];
  const visible = category === 'All' ? menu : menu.filter((m) => m.category === category);

  if (loading) return <p className="muted">Loading menu…</p>;
  if (error) return <p className="alert error">{error}</p>;

  return (
    <>
      <h1>Our Menu</h1>
      <div className="chips">
        {categories.map((c) => (
          <button key={c} className={c === category ? 'chip active' : 'chip'} onClick={() => setCategory(c)}>{c}</button>
        ))}
      </div>
      {visible.length === 0 && <p className="muted">No items yet.</p>}
      <div className="grid">
        {visible.map((item) => {
          const size = item.hasSizes ? sizes[item.id] || 'Small' : null;
          const price = size ? item.sizePrices[size] : item.price;
          const key = `${item.id}-${size || 'none'}`;
          const inCart = items.find((i) => i.key === key);
          return (
            <article key={item.id} className={item.available ? 'card' : 'card sold-out'}>
              <span className="tag">{item.category}</span>
              <h3>{item.name}</h3>
              <p className="muted">{item.description}</p>
              {item.hasSizes && (
                <div className="sizes" role="group" aria-label={`Size for ${item.name}`}>
                  {['Small', 'Medium', 'Large'].map((s) => (
                    <button
                      key={s}
                      type="button"
                      className={s === size ? 'size active' : 'size'}
                      onClick={() => setSizes({ ...sizes, [item.id]: s })}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
              <div className="card-footer">
                <strong>{formatPrice(price)}</strong>
                {item.available ? (
                  <button className="btn" onClick={() => addItem(item, size)}>
                    {inCart ? `Add another (${inCart.quantity})` : 'Add to cart'}
                  </button>
                ) : (
                  <span className="unavailable">Unavailable</span>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
