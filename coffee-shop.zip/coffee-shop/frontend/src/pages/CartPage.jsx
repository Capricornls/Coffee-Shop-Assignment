import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, formatPrice } from '../api';
import { useCart } from '../context/CartContext';

export default function CartPage() {
  const { items, setQuantity, removeItem, clear, total } = useCart();
  const [customerName, setCustomerName] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  async function placeOrder(event) {
    event.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const order = await api('/api/orders', {
        method: 'POST',
        body: {
          customerName,
          notes,
          items: items.map((i) => ({ menuItemId: i.id, size: i.size, quantity: i.quantity })),
        },
      });
      clear();
      navigate(`/order/${order.id}`);
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return (
      <>
        <h1>Your Cart</h1>
        <p className="muted">Your cart is empty. <Link to="/">Browse the menu</Link></p>
      </>
    );
  }

  return (
    <>
      <h1>Your Cart</h1>
      <table className="table">
        <thead>
          <tr><th>Item</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr>
        </thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.key}>
              <td>{i.name}{i.size && ` (${i.size})`}</td>
              <td>{formatPrice(i.price)}</td>
              <td>
                <div className="qty">
                  <button onClick={() => setQuantity(i.key, i.quantity - 1)} aria-label={`Decrease ${i.name}`}>−</button>
                  <span>{i.quantity}</span>
                  <button onClick={() => setQuantity(i.key, i.quantity + 1)} aria-label={`Increase ${i.name}`}>+</button>
                </div>
              </td>
              <td>{formatPrice(i.price * i.quantity)}</td>
              <td><button className="link danger" onClick={() => removeItem(i.key)}>Remove</button></td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr><td colSpan="3"><strong>Total</strong></td><td colSpan="2"><strong>{formatPrice(total)}</strong></td></tr>
        </tfoot>
      </table>

      <form className="panel" onSubmit={placeOrder}>
        <h2>Place your order</h2>
        <label>
          Your name
          <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} required minLength={2} maxLength={60} />
        </label>
        <label>
          Notes (optional)
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={200} rows={2} placeholder="e.g. oat milk, no sugar" />
        </label>
        {error && <p className="alert error">{error}</p>}
        <button className="btn" disabled={submitting}>{submitting ? 'Placing order…' : 'Place order'}</button>
      </form>
    </>
  );
}
