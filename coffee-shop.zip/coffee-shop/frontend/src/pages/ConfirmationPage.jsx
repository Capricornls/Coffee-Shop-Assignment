import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, formatPrice } from '../api';

export default function ConfirmationPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');

  // Re-check every 10 seconds so the customer sees status changes.
  useEffect(() => {
    function load() {
      api(`/api/orders/${id}`).then(setOrder).catch((e) => setError(e.message));
    }
    load();
    const timer = setInterval(load, 10000);
    return () => clearInterval(timer);
  }, [id]);

  if (error) return <p className="alert error">{error}</p>;
  if (!order) return <p className="muted">Loading your order…</p>;

  return (
    <div className="panel confirmation">
      <h1>Thank you, {order.customerName}!</h1>
      <p>Your order number is</p>
      <p className="order-number">{order.orderNumber}</p>
      <p>Status: <span className={`status ${order.status}`}>{order.status}</span></p>
      <table className="table">
        <tbody>
          {order.items.map((line) => (
            <tr key={line.menuItemId + (line.size || '')}>
              <td>{line.quantity} × {line.name}{line.size && ` (${line.size})`}</td>
              <td>{formatPrice(line.lineTotal)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr><td><strong>Total</strong></td><td><strong>{formatPrice(order.total)}</strong></td></tr>
        </tfoot>
      </table>
      {order.notes && <p className="muted">Notes: {order.notes}</p>}
      <Link className="btn" to="/">Back to menu</Link>
    </div>
  );
}
