import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import OrdersTab from '../components/OrdersTab';
import MenuTab from '../components/MenuTab';
import SummaryTab from '../components/SummaryTab';

export default function StaffDashboard() {
  const { logout } = useAuth();
  const [tab, setTab] = useState('orders');

  return (
    <>
      <div className="row between">
        <h1>Staff dashboard</h1>
        <button className="btn secondary" onClick={logout}>Log out</button>
      </div>
      <div className="chips">
        {[['orders', 'Orders'], ['menu', 'Manage menu'], ['summary', 'Daily summary']].map(([key, label]) => (
          <button key={key} className={tab === key ? 'chip active' : 'chip'} onClick={() => setTab(key)}>{label}</button>
        ))}
      </div>
      {tab === 'orders' && <OrdersTab />}
      {tab === 'menu' && <MenuTab />}
      {tab === 'summary' && <SummaryTab />}
    </>
  );
}
