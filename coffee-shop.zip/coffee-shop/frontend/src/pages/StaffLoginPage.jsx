import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function StaffLoginPage() {
  const { token, login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  if (token) return <Navigate to="/staff" replace />;

  async function submit(event) {
    event.preventDefault();
    setError('');
    try {
      await login(username, password);
      navigate('/staff');
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <form className="panel narrow" onSubmit={submit}>
      <h1>Staff login</h1>
      <label>Username<input value={username} onChange={(e) => setUsername(e.target.value)} required /></label>
      <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
      {error && <p className="alert error">{error}</p>}
      <button className="btn">Log in</button>
    </form>
  );
}
