// Integration tests: run with `npm test` (needs a Redis at TEST_REDIS_URL, default localhost:6379 db 15).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createRedis } from '../src/redis.js';
import { createStore } from '../src/store.js';
import { createApp } from '../src/app.js';

process.env.JWT_SECRET = 'test-secret';
process.env.STAFF_USERNAME = 'staff';
process.env.STAFF_PASSWORD = 'pw123';

let redis, server, base, token;

async function call(method, path, body, auth) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(auth ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null };
}

before(async () => {
  redis = createRedis(process.env.TEST_REDIS_URL || 'redis://localhost:6379/15');
  await redis.flushdb();
  server = createApp(createStore(redis), redis).listen(0);
  base = `http://localhost:${server.address().port}`;
  token = (await call('POST', '/api/auth/login', { username: 'staff', password: 'pw123' })).body.token;
});

after(async () => {
  await redis.flushdb();
  server.close();
  redis.disconnect();
});

test('health check works', async () => {
  const r = await call('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.body.status, 'ok');
});

test('login rejects wrong password', async () => {
  const r = await call('POST', '/api/auth/login', { username: 'staff', password: 'nope' });
  assert.equal(r.status, 401);
});

test('staff endpoints need a token', async () => {
  assert.equal((await call('POST', '/api/menu', { name: 'X' })).status, 401);
  assert.equal((await call('GET', '/api/orders')).status, 401);
});

test('full flow: menu CRUD, order, status, summary', async () => {
  // validation
  const bad = await call('POST', '/api/menu', { name: 'A', price: -1 }, true);
  assert.equal(bad.status, 400);

  // create + update menu
  const created = await call('POST', '/api/menu', { name: 'Mocha', category: 'Coffee', price: 35, description: 'Choc' }, true);
  assert.equal(created.status, 201);
  const id = created.body.id;
  const put = await call('PUT', `/api/menu/${id}`, { price: 40 }, true);
  assert.equal(put.body.price, 40);

  const off = await call('POST', '/api/menu', { name: 'Sold Out', category: 'Pastry', price: 10, available: false }, true);

  // customer lists menu (public)
  const menu = await call('GET', '/api/menu');
  assert.equal(menu.body.length, 2);

  // sized drink: Large costs Small + 10
  const sized = await call('POST', '/api/menu', { name: 'Sized Latte', category: 'Coffee', price: 30, hasSizes: true }, true);
  assert.equal(sized.body.sizePrices.Large, 40);
  const sizedOrder = await call('POST', '/api/orders', { customerName: 'Lerato', items: [{ menuItemId: sized.body.id, quantity: 1, size: 'Large' }] });
  assert.equal(sizedOrder.body.total, 40);
  assert.equal(sizedOrder.body.items[0].size, 'Large');
  assert.equal((await call('POST', '/api/orders', { customerName: 'Lerato', items: [{ menuItemId: sized.body.id, quantity: 1, size: 'Huge' }] })).status, 400);
  await call('DELETE', `/api/menu/${sized.body.id}`, null, true);

  // order
  const order = await call('POST', '/api/orders', { customerName: 'Thabo', items: [{ menuItemId: id, quantity: 2 }] });
  assert.equal(order.status, 201);
  assert.equal(order.body.total, 80);
  assert.equal(order.body.status, 'Pending');
  assert.match(order.body.orderNumber, /^CS-\d+$/);

  // unavailable / unknown / invalid
  assert.equal((await call('POST', '/api/orders', { customerName: 'T', items: [{ menuItemId: off.body.id, quantity: 1 }] })).status, 400);
  assert.equal((await call('POST', '/api/orders', { customerName: 'Thabo', items: [{ menuItemId: off.body.id, quantity: 1 }] })).status, 409);
  assert.equal((await call('POST', '/api/orders', { customerName: 'Thabo', items: [{ menuItemId: 'nope', quantity: 1 }] })).status, 400);

  // status flow
  const patched = await call('PATCH', `/api/orders/${order.body.id}/status`, { status: 'Preparing' }, true);
  assert.equal(patched.body.status, 'Preparing');
  assert.equal((await call('PATCH', `/api/orders/${order.body.id}/status`, { status: 'Bogus' }, true)).status, 400);

  // lookup + list + summary
  assert.equal((await call('GET', `/api/orders/${order.body.id}`)).body.customerName, 'Thabo');
  assert.equal((await call('GET', '/api/orders', null, true)).body.length, 2);
  const summary = await call('GET', '/api/orders/summary/daily', null, true);
  assert.equal(summary.body.orderCount, 2);
  assert.equal(summary.body.totalSales, 120);
  assert.equal(summary.body.byStatus.Preparing, 1);

  // delete
  assert.equal((await call('DELETE', `/api/menu/${id}`, null, true)).status, 204);
  assert.equal((await call('GET', `/api/menu/${id}`)).status, 404);
});
