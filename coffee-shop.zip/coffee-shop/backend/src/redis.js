import Redis from 'ioredis';

// One shared Redis connection for the whole backend.
// REDIS_URL comes from the environment so credentials never live in the code.
export function createRedis(url) {
  const client = new Redis(url || 'redis://localhost:6379', {
    maxRetriesPerRequest: 3,
  });
  client.on('error', (err) => console.error('Redis error:', err.message));
  return client;
}
