import { randomUUID } from 'node:crypto';

// Data layer. Everything stored in Redis is a key -> JSON string pair.
//
//   menu:<id>          JSON of one menu item
//   menu:ids           SET of all menu item ids
//   order:<id>         JSON of one order
//   orders:ids         SET of all order ids
//   orders:counter     integer, INCR'd to produce friendly order numbers
export function createStore(redis) {
  async function readMany(prefix, setKey) {
    const ids = await redis.smembers(setKey);
    if (ids.length === 0) return [];
    const raw = await redis.mget(ids.map((id) => `${prefix}:${id}`));
    return raw.filter(Boolean).map((text) => JSON.parse(text));
  }

  return {
    // ---------- menu ----------
    listMenu: () => readMany('menu', 'menu:ids'),

    async getMenuItem(id) {
      const text = await redis.get(`menu:${id}`);
      return text ? JSON.parse(text) : null;
    },

    async createMenuItem(data) {
      const item = { id: randomUUID(), ...data, createdAt: new Date().toISOString() };
      await redis.multi().set(`menu:${item.id}`, JSON.stringify(item)).sadd('menu:ids', item.id).exec();
      return item;
    },

    async updateMenuItem(id, data) {
      const existing = await this.getMenuItem(id);
      if (!existing) return null;
      const item = { ...existing, ...data, id, updatedAt: new Date().toISOString() };
      await redis.set(`menu:${id}`, JSON.stringify(item));
      return item;
    },

    async deleteMenuItem(id) {
      const removed = await redis.del(`menu:${id}`);
      await redis.srem('menu:ids', id);
      return removed > 0;
    },

    // ---------- orders ----------
    listOrders: () => readMany('order', 'orders:ids'),

    async getOrder(id) {
      const text = await redis.get(`order:${id}`);
      return text ? JSON.parse(text) : null;
    },

    async createOrder(data) {
      const counter = await redis.incr('orders:counter');
      const order = {
        id: randomUUID(),
        orderNumber: `CS-${String(1000 + counter)}`,
        ...data,
        status: 'Pending',
        createdAt: new Date().toISOString(),
      };
      await redis.multi().set(`order:${order.id}`, JSON.stringify(order)).sadd('orders:ids', order.id).exec();
      return order;
    },

    async updateOrderStatus(id, status) {
      const order = await this.getOrder(id);
      if (!order) return null;
      order.status = status;
      order.updatedAt = new Date().toISOString();
      await redis.set(`order:${id}`, JSON.stringify(order));
      return order;
    },
  };
}
