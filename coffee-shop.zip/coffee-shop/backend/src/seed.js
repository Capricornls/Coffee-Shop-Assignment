import { SIZES } from './sizes.js';

// Starter menu. Drinks come in Small / Medium / Large (hasSizes). Price is the Small price.
const SAMPLE_ITEMS = [
  { name: 'Espresso', description: 'Strong, rich single shot', category: 'Coffee', price: 20, hasSizes: true },
  { name: 'Americano', description: 'Espresso topped up with hot water', category: 'Coffee', price: 24, hasSizes: true },
  { name: 'Cappuccino', description: 'Espresso with steamed milk and thick foam', category: 'Coffee', price: 32, hasSizes: true },
  { name: 'Latte', description: 'Smooth espresso with lots of steamed milk', category: 'Coffee', price: 34, hasSizes: true },
  { name: 'Flat White', description: 'Double espresso with velvety microfoam', category: 'Coffee', price: 34, hasSizes: true },
  { name: 'Mocha', description: 'Espresso, chocolate and steamed milk', category: 'Coffee', price: 38, hasSizes: true },
  { name: 'Macchiato', description: 'Espresso marked with a spoon of foam', category: 'Coffee', price: 26, hasSizes: true },
  { name: 'Cortado', description: 'Equal parts espresso and warm milk', category: 'Coffee', price: 30, hasSizes: true },
  { name: 'Matcha Latte', description: 'Ceremonial-style matcha with steamed milk', category: 'Matcha', price: 38, hasSizes: true },
  { name: 'Iced Matcha Latte', description: 'Matcha shaken over ice with cold milk', category: 'Matcha', price: 40, hasSizes: true },
  { name: 'Rooibos Tea', description: 'Caffeine-free South African classic', category: 'Tea', price: 22, hasSizes: true },
  { name: 'Chai Latte', description: 'Spiced tea with steamed milk', category: 'Tea', price: 30, hasSizes: true },
  { name: 'Butter Croissant', description: 'Freshly baked each morning', category: 'Pastry', price: 25, hasSizes: false },
  { name: 'Blueberry Muffin', description: 'Soft muffin with real blueberries', category: 'Pastry', price: 28, hasSizes: false },
];

const SEED_VERSION = '2';

// Runs once per seed version. Adds any starter item that is missing (matched by name)
// and switches on sizes for starter items that already existed. Items staff add are never touched.
export async function seedMenuIfEmpty(store, redis) {
  if ((await redis.get('seed:version')) === SEED_VERSION) return;

  const existing = await store.listMenu();
  for (const sample of SAMPLE_ITEMS) {
    const match = existing.find((m) => m.name === sample.name);
    if (match) {
      if (match.hasSizes === undefined) await store.updateMenuItem(match.id, { hasSizes: sample.hasSizes });
    } else {
      await store.createMenuItem({ ...sample, available: true });
    }
  }
  await redis.set('seed:version', SEED_VERSION);
  console.log(`Menu seeded (sizes: ${SIZES.join('/')})`);
}
