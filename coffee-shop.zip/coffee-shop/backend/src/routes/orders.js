import { Router } from 'express';
import { requireStaff } from '../auth.js';
import { validateOrder, validateStatus } from '../validate.js';
import { priceForSize } from '../sizes.js';

export function orderRoutes(store) {
  const router = Router();

  // Staff: list all orders (newest first). Optional ?status=Pending filter.
  router.get('/', requireStaff, async (req, res) => {
    let orders = await store.listOrders();
    if (req.query.status) orders = orders.filter((o) => o.status === req.query.status);
    orders.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.json(orders);
  });

  // Staff: daily summary. ?date=YYYY-MM-DD (defaults to today, UTC)
  router.get('/summary/daily', requireStaff, async (req, res) => {
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'date must be YYYY-MM-DD' });

    const orders = (await store.listOrders()).filter((o) => o.createdAt.startsWith(date));
    const byStatus = { Pending: 0, Preparing: 0, Ready: 0, Collected: 0 };
    let totalSales = 0;
    let itemsSold = 0;
    for (const order of orders) {
      byStatus[order.status] += 1;
      totalSales += order.total;
      for (const line of order.items) itemsSold += line.quantity;
    }
    res.json({
      date,
      orderCount: orders.length,
      itemsSold,
      totalSales: Math.round(totalSales * 100) / 100,
      byStatus,
    });
  });

  // Public: customer places an order. Prices come from the server, never from the client.
  router.post('/', async (req, res) => {
    const { errors, value } = validateOrder(req.body);
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });

    const lines = [];
    let total = 0;
    for (const line of value.items) {
      const item = await store.getMenuItem(line.menuItemId);
      if (!item) return res.status(400).json({ error: `Menu item ${line.menuItemId} does not exist` });
      if (!item.available) return res.status(409).json({ error: `${item.name} is currently unavailable` });
      // Items without sizes ignore any size; sized items default to Small.
      const size = item.hasSizes ? line.size || 'Small' : null;
      const price = priceForSize(item, size);
      const lineTotal = Math.round(price * line.quantity * 100) / 100;
      total += lineTotal;
      lines.push({ menuItemId: item.id, name: item.name, size, price, quantity: line.quantity, lineTotal });
    }

    const order = await store.createOrder({
      customerName: value.customerName,
      notes: value.notes,
      items: lines,
      total: Math.round(total * 100) / 100,
    });
    res.status(201).json(order);
  });

  // Public: look up one order (used by the confirmation page; id is a random UUID)
  router.get('/:id', async (req, res) => {
    const order = await store.getOrder(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  });

  // Staff: change status
  router.patch('/:id/status', requireStaff, async (req, res) => {
    const { errors, value } = validateStatus(req.body);
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
    const order = await store.updateOrderStatus(req.params.id, value);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  });

  return router;
}
