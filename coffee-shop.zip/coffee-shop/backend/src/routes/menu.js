import { Router } from 'express';
import { requireStaff } from '../auth.js';
import { validateMenuItem } from '../validate.js';
import { withSizePrices } from '../sizes.js';

export function menuRoutes(store) {
  const router = Router();

  // Public: customers browse the menu
  router.get('/', async (req, res) => {
    const items = await store.listMenu();
    items.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
    res.json(items.map(withSizePrices));
  });

  router.get('/:id', async (req, res) => {
    const item = await store.getMenuItem(req.params.id);
    if (!item) return res.status(404).json({ error: 'Menu item not found' });
    res.json(withSizePrices(item));
  });

  // Staff only: add / update / delete
  router.post('/', requireStaff, async (req, res) => {
    const { errors, value } = validateMenuItem(req.body);
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
    res.status(201).json(withSizePrices(await store.createMenuItem(value)));
  });

  router.put('/:id', requireStaff, async (req, res) => {
    const { errors, value } = validateMenuItem(req.body, { partial: true });
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
    const item = await store.updateMenuItem(req.params.id, value);
    if (!item) return res.status(404).json({ error: 'Menu item not found' });
    res.json(withSizePrices(item));
  });

  router.delete('/:id', requireStaff, async (req, res) => {
    const deleted = await store.deleteMenuItem(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Menu item not found' });
    res.status(204).end();
  });

  return router;
}
