import { SIZES } from './sizes.js';

// Small hand-written validators. Each returns { errors: [...], value: {...} }.
export const ORDER_STATUSES = ['Pending', 'Preparing', 'Ready', 'Collected'];

export function validateMenuItem(body, { partial = false } = {}) {
  const errors = [];
  const value = {};
  const b = body && typeof body === 'object' ? body : {};

  if (!partial || b.name !== undefined) {
    if (typeof b.name !== 'string' || b.name.trim().length < 2 || b.name.trim().length > 60) {
      errors.push('name must be text between 2 and 60 characters');
    } else value.name = b.name.trim();
  }
  if (!partial || b.description !== undefined) {
    if (b.description !== undefined && typeof b.description !== 'string') errors.push('description must be text');
    else value.description = (b.description || '').trim().slice(0, 200);
  }
  if (!partial || b.category !== undefined) {
    if (typeof b.category !== 'string' || !b.category.trim()) errors.push('category is required (e.g. Coffee, Tea, Pastry)');
    else value.category = b.category.trim();
  }
  if (!partial || b.price !== undefined) {
    const price = Number(b.price);
    if (b.price === '' || b.price === null || !Number.isFinite(price) || price <= 0 || price > 10000) {
      errors.push('price must be a number greater than 0');
    } else value.price = Math.round(price * 100) / 100;
  }
  if (!partial || b.available !== undefined) {
    if (b.available !== undefined && typeof b.available !== 'boolean') errors.push('available must be true or false');
    else value.available = b.available === undefined ? true : b.available;
  }
  if (!partial || b.hasSizes !== undefined) {
    if (b.hasSizes !== undefined && typeof b.hasSizes !== 'boolean') errors.push('hasSizes must be true or false');
    else value.hasSizes = b.hasSizes === undefined ? false : b.hasSizes;
  }
  if (partial && Object.keys(value).length === 0 && errors.length === 0) errors.push('no valid fields supplied');
  return { errors, value };
}

export function validateOrder(body) {
  const errors = [];
  const b = body && typeof body === 'object' ? body : {};
  const value = {};

  if (typeof b.customerName !== 'string' || b.customerName.trim().length < 2 || b.customerName.trim().length > 60) {
    errors.push('customerName must be between 2 and 60 characters');
  } else value.customerName = b.customerName.trim();

  value.notes = typeof b.notes === 'string' ? b.notes.trim().slice(0, 200) : '';

  if (!Array.isArray(b.items) || b.items.length === 0) {
    errors.push('items must be a non-empty list');
  } else if (b.items.length > 50) {
    errors.push('too many items in one order');
  } else {
    value.items = [];
    for (const line of b.items) {
      const quantity = Number(line && line.quantity);
      if (!line || typeof line.menuItemId !== 'string' || !Number.isInteger(quantity) || quantity < 1 || quantity > 20) {
        errors.push('each item needs a menuItemId and a whole-number quantity from 1 to 20');
        break;
      }
      if (line.size !== undefined && line.size !== null && !SIZES.includes(line.size)) {
        errors.push(`size must be one of: ${SIZES.join(', ')}`);
        break;
      }
      value.items.push({ menuItemId: line.menuItemId, quantity, size: line.size || null });
    }
  }
  return { errors, value };
}

export function validateStatus(body) {
  const status = body && body.status;
  if (!ORDER_STATUSES.includes(status)) {
    return { errors: [`status must be one of: ${ORDER_STATUSES.join(', ')}`], value: null };
  }
  return { errors: [], value: status };
}
