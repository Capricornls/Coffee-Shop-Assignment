import express from 'express';
import cors from 'cors';
import { menuRoutes } from './routes/menu.js';
import { orderRoutes } from './routes/orders.js';
import { checkStaffLogin, signToken } from './auth.js';

export function createApp(store, redis) {
  const app = express();

  const origins = (process.env.CORS_ORIGIN || '*').split(',').map((s) => s.trim());
  app.use(cors({ origin: origins.includes('*') ? true : origins }));
  app.use(express.json({ limit: '50kb' }));

  app.get('/api/health', async (req, res) => {
    try {
      await redis.ping();
      res.json({ status: 'ok', database: 'connected', time: new Date().toISOString() });
    } catch {
      res.status(503).json({ status: 'error', database: 'unreachable' });
    }
  });

  app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body || {};
    if (!checkStaffLogin(username, password)) return res.status(401).json({ error: 'Wrong username or password' });
    res.json({ token: signToken(username) });
  });

  app.use('/api/menu', menuRoutes(store));
  app.use('/api/orders', orderRoutes(store));

  // 404 for unknown routes
  app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

  // Bad JSON bodies and anything unexpected end up here, in the same error format
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Request body is not valid JSON' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server' });
  });

  return app;
}
