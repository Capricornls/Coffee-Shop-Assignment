import jwt from 'jsonwebtoken';
import { timingSafeEqual } from 'node:crypto';

function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
}

export function checkStaffLogin(username, password) {
  return safeEqual(username, process.env.STAFF_USERNAME || '') && safeEqual(password, process.env.STAFF_PASSWORD || '');
}

export function signToken(username) {
  return jwt.sign({ role: 'staff', username }, process.env.JWT_SECRET, { expiresIn: '8h' });
}

// Express middleware: only lets requests through that carry a valid staff token.
export function requireStaff(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Login required' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.role !== 'staff') return res.status(403).json({ error: 'Staff access only' });
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}
