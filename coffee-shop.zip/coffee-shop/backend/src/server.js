import 'dotenv/config';
import { createRedis } from './redis.js';
import { createStore } from './store.js';
import { createApp } from './app.js';
import { seedMenuIfEmpty } from './seed.js';

for (const name of ['REDIS_URL', 'JWT_SECRET', 'STAFF_USERNAME', 'STAFF_PASSWORD']) {
  if (!process.env[name]) {
    console.error(`Missing environment variable: ${name} (see .env.example)`);
    process.exit(1);
  }
}

const redis = createRedis(process.env.REDIS_URL);
const store = createStore(redis);
await seedMenuIfEmpty(store, redis);

const port = process.env.PORT || 4000;
createApp(store, redis).listen(port, () => console.log(`Coffee shop API listening on port ${port}`));
