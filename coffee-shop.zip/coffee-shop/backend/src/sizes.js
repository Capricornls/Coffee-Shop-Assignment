// Cup sizes. Small uses the item's base price; Medium and Large add a fixed extra.
export const SIZES = ['Small', 'Medium', 'Large'];
export const SIZE_EXTRA = { Small: 0, Medium: 5, Large: 10 };

export function priceForSize(item, size) {
  if (!item.hasSizes) return item.price;
  return Math.round((item.price + SIZE_EXTRA[size]) * 100) / 100;
}

// Adds a sizePrices object to a menu item for the API response (not stored in Redis).
export function withSizePrices(item) {
  if (!item.hasSizes) return item;
  const sizePrices = {};
  for (const size of SIZES) sizePrices[size] = priceForSize(item, size);
  return { ...item, sizePrices };
}
